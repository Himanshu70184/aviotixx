export const defaultBlogs = [
  {
    title: 'Best Time to Visit India',
    excerpt: 'Discover the ideal months to book your flight to India for perfect weather and festivals.',
    image: 'https://images.unsplash.com/photo-1748951447152-5a9992576e6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    readTime: '5 min read',
    slug: 'best-time-to-visit-india',
    order: 1,
    isActive: true,
  },
  {
    title: 'Top 10 Indian Festivals',
    excerpt: 'Plan your trip around these colorful celebrations for an unforgettable experience.',
    image: 'https://images.unsplash.com/photo-1635247055412-6007edbd9af7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    readTime: '7 min read',
    slug: 'top-10-indian-festivals',
    order: 2,
    isActive: true,
  },
  {
    title: 'Must-Try Indian Cuisines',
    excerpt: "From street food to fine dining - a foodie's guide to culinary adventures in India.",
    image: 'https://images.unsplash.com/photo-1728364283053-b1e2abe71611?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    readTime: '6 min read',
    slug: 'must-try-indian-cuisines',
    order: 3,
    isActive: true,
  },
];

export const defaultTestimonials = [
  {
    name: 'Priya Sharma',
    location: 'New York, NY',
    message: "Saved $427 on family tickets! The phone agent found deals I couldn't find anywhere else online.",
    rating: 5,
    image: 'https://images.unsplash.com/photo-1762341120638-b5b9358ef571?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    isActive: true,
  },
  {
    name: 'Rajesh Patel',
    location: 'San Francisco, CA',
    message: 'Got a direct flight to Mumbai for $699 when everyone else wanted $1,200+.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1598268012815-ae21095df31b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    isActive: true,
  },
  {
    name: 'Sarah Johnson',
    location: 'Chicago, IL',
    message: 'Saved over $500 on business class. Agent helped me get better seats.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1650113794972-56031832c0db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=1080',
    isActive: true,
  },
];

export const defaultFaqs = [
  {
    question: 'Why are phone prices cheaper?',
    answer: "We have exclusive airline contracts and unpublished consolidator fares available only by phone.",
    order: 1,
    isActive: true,
  },
  {
    question: 'Is it safe to book over the phone?',
    answer: "Absolutely. We use secure payment processing and never store card details.",
    order: 2,
    isActive: true,
  },
  {
    question: 'How quickly can I book?',
    answer: 'Most calls take 5-10 minutes and confirmation is sent immediately.',
    order: 3,
    isActive: true,
  },
];

export const defaultSettings = {
  singletonKey: 'main',
  seo: {
    title: 'Aviotixx - Cheap Flights to India',
    description: 'Book affordable flights to India with exclusive phone-only fares and 24/7 support.',
    keywords: 'flights to india, cheap flights, travel deals, aviotixx',
  },
  contact: {
    phoneDisplay: '1-800-123-4567',
    phoneTel: '+18001234567',
    email: 'support@aviotixx.com',
    address: 'New York, USA',
  },
};
