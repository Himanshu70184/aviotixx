import { useEffect, useState } from 'react';
import { Loader2, Mail, Phone, Plane } from 'lucide-react';
import { getInquiries, updateInquiry, type FlightInquiry } from '../../services/adminApi';

const TRIP_TYPES = ['One Way', 'Round Trip', 'Multi-City'];
const CABINS = ['Economy', 'First', 'Business', '', 'Premium Economy'];
const STATUSES = ['pending', 'approved', 'rejected', 'booked'];
const STATUS_COLORS: Record<string, string> = {
  pending:  'bg-yellow-100 text-yellow-700',
  approved: 'bg-green-100 text-green-700',
  booked:   'bg-blue-100 text-blue-700',
  rejected: 'bg-red-100 text-red-700',
};

export function AdminInquiriesPage() {
  const [inquiries, setInquiries] = useState<FlightInquiry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [updating, setUpdating] = useState<string | null>(null);

  useEffect(() => {
    getInquiries()
      .then(setInquiries)
      .catch(() => setError('Failed to load inquiries'))
      .finally(() => setLoading(false));
  }, []);

  async function handleStatusChange(id: string, status: string) {
    setUpdating(id);
    try {
      const updated = await updateInquiry(id, { status });
      setInquiries(prev => prev.map(inq => inq._id === id ? { ...inq, ...updated } : inq));
    } catch {
      alert('Failed to update status');
    } finally {
      setUpdating(null);
    }
  }

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Flight Inquiries</h1>
        <p className="text-gray-500 text-sm mt-1">{inquiries.length} total submissions</p>
      </div>

      {error && <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg p-3 mb-4 text-sm">{error}</div>}

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-gray-400" /></div>
      ) : inquiries.length === 0 ? (
        <div className="bg-white rounded-xl border border-dashed border-gray-200 p-12 text-center">
          <p className="text-gray-500">No inquiries yet.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {inquiries.map(inq => (
            <div key={inq._id} className="bg-white rounded-xl border border-gray-100 shadow-sm p-4">
              <div className="flex items-start gap-4">
                {/* Route */}
                <div className="bg-blue-50 rounded-lg p-3 flex-shrink-0 text-center min-w-[100px]">
                  <div className="flex items-center gap-1 text-sm font-bold text-[#1E3A8A]">
                    <span>{inq.origin}</span>
                    <Plane className="w-3 h-3" />
                    <span>{inq.destination}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{TRIP_TYPES[inq.tripType] || 'One Way'}</p>
                  <p className="text-xs text-gray-500">{CABINS[inq.cabin] || 'Economy'}</p>
                </div>

                {/* Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-semibold text-gray-900 text-sm">{inq.passengerName}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[inq.status] || 'bg-gray-100 text-gray-600'}`}>
                      {inq.status}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-3 text-xs text-gray-600">
                    <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{inq.passengerEmail}</span>
                    <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{inq.passengerPhone}</span>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-1.5 text-xs text-gray-500">
                    <span>Depart: <strong>{inq.departDate ? new Date(inq.departDate).toLocaleDateString() : '-'}</strong></span>
                    {inq.returnDate && <span>Return: <strong>{new Date(inq.returnDate).toLocaleDateString()}</strong></span>}
                    <span>Pax: <strong>{inq.adults}A {inq.children}C {inq.infants}I</strong></span>
                    {inq.selectedFlight && <span>Flight: <strong>{inq.selectedFlight.airline}</strong> - <strong>${inq.selectedFlight.price}</strong></span>}
                  </div>
                </div>

                {/* Status + Date */}
                <div className="text-right flex-shrink-0 flex flex-col items-end gap-2">
                  <p className="text-xs text-gray-400">{new Date(inq.createdAt).toLocaleDateString()}</p>
                  <p className="text-xs text-gray-400">{new Date(inq.createdAt).toLocaleTimeString()}</p>
                  <div className="relative">
                    {updating === inq._id
                      ? <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
                      : <select
                          value={inq.status}
                          onChange={e => handleStatusChange(inq._id, e.target.value)}
                          className="text-xs border border-gray-200 rounded-lg px-2 py-1 bg-white text-gray-700 cursor-pointer hover:border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400"
                        >
                          {STATUSES.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                        </select>
                    }
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
